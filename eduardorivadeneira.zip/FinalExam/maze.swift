
import Foundation

func maze() {
    let t = Int(readLine()!)!
    
    for _ in 0..<t {
        let r = Int(readLine()!)!
        let c = Int(readLine()!)!
        var map = [[String]]()
        for _ in 0..<r {
            let text = readLine()!//.split(separator: " ").map { String($0) }
            
            var row = [String]()
            for char in text {
                row.append(String(char))
            }
            

            map.append(row)
        }
        
        for m in map {
            print(m)
        }
        
        var steps = [[Int]](repeating: [Int](repeating: 999, count: c), count: r)
        steps[0][0] = 1
        
        for s in steps {
            print(s)
        }
        
        print(leastStepsToPoint(x: 0, y: 0))
        
        func leastStepsToPoint(x: Int, y: Int) -> Int {
            
            
            
            return -9
        }
        
    }
    
    func isWithinBounds(x: Int, y: Int, c: Int, r: Int) -> Bool {
        return x >= 0 && x < c && y >= 0 && y < r
    }
}

