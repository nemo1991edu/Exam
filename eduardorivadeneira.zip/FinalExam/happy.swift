
import Foundation


func happy() {
    
    let word = readLine()!
    let res = happyHelper(word: word)
    if res == 0 { print("none") }
    if res > 0 { print("happy") }
    if res < 0 { print("sad") }

}

func happyHelper(word: String) -> Int {
    

    if word.count <= 2 {
        return 0
    }
    
    if word[0] == ":" && word[1] == "-" {
        if word[2] == ")" {
            return happyHelper(word: String(word.suffix(word.count - 3))) + 1
        } else if word[2] == "(" {
            return happyHelper(word: String(word.suffix(word.count - 3))) - 1
        } else {
            return happyHelper(word: String(word.suffix(word.count - 2)))
        }
    } else {
        return happyHelper(word: String(word.suffix(word.count - 1)))
    }
    
    
    

}
