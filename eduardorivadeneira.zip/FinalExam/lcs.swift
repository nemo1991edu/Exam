
import Foundation


func lcs() {
    let str1 = readLine()!
    let str2 = readLine()!
    

    
    print(lcsHelper(start1: 0, start2: 0))

    
    func lcsHelper(start1: Int, start2: Int) -> Int {
        if start1 >= str1.count {
            return 0
        }
        if start2 >= str2.count {
            return 0
        }
        
        if str1[start1] == str2[start2] {
            return lcsHelper(start1: start1 + 1, start2: start2 + 1) + 1
        } else {
            var count1 = lcsHelper(start1: start1, start2: start2 + 1)
            var count2 = lcsHelper(start1: start1 + 1, start2: start2)
            return max(count1, count2)
        }
    }
}
