
import Foundation


func duplicate() {
    let list = readLine()!.split(separator: " ").map { Int($0)! }
    
    print(list)
    
    var arr = [Bool](repeating: false, count: 1_000_000)
    
    for value in list {
        if arr[value] {
            print(value)
            return
        } else {
            arr[value] = true
        }
        

}
