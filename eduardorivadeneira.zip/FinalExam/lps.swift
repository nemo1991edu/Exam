
import Foundation


func lps() {
    
    let word = readLine()!
    print(lpsHelper(word: word))
}

func lpsHelper(word: String) -> Int {
    
    print(word)
    if word.count == 0 {
        return 0
    }
    if word.count == 1 {
        return 1
    }

    if let first = word.first, let last = word.last, first == last {
        return lpsHelper(word: String(String(word.suffix(word.count - 1)).prefix(word.count - 1))) + 2
    } else {
        let count1 = lpsHelper(word: String(word.prefix(word.count - 1)))
        let count2 = lpsHelper(word: String(word.suffix(word.count - 1)))
        return min(count1, count2)
    }
    
}
