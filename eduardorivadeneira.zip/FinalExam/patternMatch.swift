
import Foundation


func patternMatch() {
    let n = Int(readLine()!)!
    
    var queries = [String]()
    for _ in 0..<n {
        queries.append(readLine()!)
    }
    
    var pattern = readLine()!
    
    print(n, pattern)
    print(queries)
    
    var x = "p"
    
    print(x == x.uppercased())
    
    var query = queries[0]
    
    var arr = [[String]]()
    var last = 0
    for i in 0..<query.count {
        var c = query[i]
        if c == c.uppercased() && i != 0 {
            let first = String(query[query.index(query.startIndex, offsetBy: last)...query.index(query.startIndex, offsetBy: i-1)])
            print(first)
            print(c, last)
            last = i
            print(i, "--")
            
        } else if i == query.count-1 {
            let first = String(query[query.index(query.startIndex, offsetBy: last)...query.index(query.startIndex, offsetBy: query.count-1)])
            print(first)
            print(c, last)
            last = i
            print(i, "--")
            
        }
    }
    

}
