
import Foundation

func corona() {
    var p = Int(readLine()!)!
    var n = Int(readLine()!)!
    let r = Int(readLine()!)!
    
//    print(n, p, r)
    
    p = p - n
    
    var days = 0
    while p >= 0 {
        n = Int(n * r)
        p = p - n
        days += 1
//        print(days, p, n)
    }
    
//    while n < p {
//        n = Int(n * r)
//        days += 1
//        print(days, n)
//    }
    
    print(days)
}
